# WoLua scripting examples

These scripts are, technically, usable directly. You can drop the folders into your script repository and they'll work fine. They are _not_ actually intended for use, but an example isn't much good if it doesn't _work_.

Please note that while these scripts _are_ documented via comments, the [actual documentation](https://github.com/PrincessRTFM/WoLua/blob/master/docs/README.md) is almost certainly much more useful, since it documents _everything_ as opposed to the pieces that the examples use.
