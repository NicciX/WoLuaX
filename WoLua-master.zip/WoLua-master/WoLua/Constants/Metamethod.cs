namespace PrincessRTFM.WoLua.Constants;

public static class Metamethod {
	public const string
		FunctionCall = "__call",
		Concatenate = "__concat",
		Stringify = "__tostring";
}
