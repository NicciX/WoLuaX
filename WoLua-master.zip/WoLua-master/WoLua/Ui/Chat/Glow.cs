using Dalamud.Game.Text.SeStringHandling.Payloads;

namespace PrincessRTFM.WoLua.Ui.Chat;

public static class Glow {
	public static readonly UIGlowPayload
		Reset = new(0);
}
